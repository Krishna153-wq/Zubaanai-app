from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    text = request.form['text']
    voice = request.form['voice']
    result = f"Generated voice using {voice} for text: {text}"
    return render_template('result.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
